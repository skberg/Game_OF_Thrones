                                                            //plaserer på start 
switch (localStorage.getItem("player 1")) {
    case "House Algood":
        var el = document.getElementById("player1");
        el.innerHTML="<img src=\"./Bilde/Icons/Algood_Gul.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Allyrion of Godsgrace":
        var el = document.getElementById("player1");
        el.innerHTML="<img src=\"./Bilde/Icons/Hand_Dark_Red.svg\" width=\"50%\" height=\"50%\">";
        break;

    case "House Amber":
        var el = document.getElementById("player1");
        el.innerHTML="<img src=\"./Bilde/Banner_Whater.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Ambrose":
        var el = document.getElementById("player1");
        el.innerHTML="<img src=\"./Bilde/Icons/Red_Mauer.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Appleton of Appleton":
        var el = document.getElementById("player1");
        el.innerHTML="<img src=\"./Bilde/Icons/Wood_Kind_Gray.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Arryn of Gulltown":
        var el = document.getElementById("player1");
        el.innerHTML="<img src=\"./Bilde/Icons/Blue_Hero.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Arryn of the Eyrie":
        var el = document.getElementById("player1");
        el.innerHTML="<img src=\"./Bilde/Icons/Blue_Hero.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Ashford of Ashford":
        var el = document.getElementById("player1");
        el.innerHTML = "<img src=\"./Bilde/Icons/Orang_son.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Ashwood":
        var el = document.getElementById("player1");
        el.innerHTML = "<img src=\"./Bilde/Icons/Red_Skog.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Baelish of Harrenhal":
        var el = document.getElementById("player1");
        el.innerHTML="<img src=\"./Bilde/Icons/Man_GReen_Fame.svg\" width=\"50%\" height=\"50%\">";
        break;

    default:
        console.log("work, no info")

}

  

//plaserer på venstere under dice1
switch (localStorage.getItem("player 1")) {
    case "House Algood":
        var el = document.getElementById("player_1");
        el.innerHTML="<img src=\"./Bilde/Icons/Algood_Gul.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Allyrion of Godsgrace":
        var el = document.getElementById("player_1");
        el.innerHTML="<img src=\"./Bilde/Icons/Hand_Dark_Red.svg\" width=\"50%\" height=\"50%\">";
        break;

    case "House Amber":
        var el = document.getElementById("player_1");
        el.innerHTML="<img src=\"./Bilde/Banner_Whater.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Ambrose":
        var el = document.getElementById("player_1");
        el.innerHTML="<img src=\"./Bilde/Icons/Red_Mauer.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Appleton of Appleton":
        var el = document.getElementById("player_1");
        el.innerHTML="<img src=\"./Bilde/Icons/Wood_Kind_Gray.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Arryn of Gulltown":
        var el = document.getElementById("player_1");
        el.innerHTML="<img src=\"./Bilde/Icons/Blue_Hero.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Arryn of the Eyrie":
        var el = document.getElementById("player_1");
        el.innerHTML="<img src=\"./Bilde/Icons/Blue_Hero.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Ashford of Ashford":
        var el = document.getElementById("player_1");
        el.innerHTML = "<img src=\"./Bilde/Icons/Orang_son.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Ashwood":
        var el = document.getElementById("player_1");
        el.innerHTML = "<img src=\"./Bilde/Icons/Red_Skog.svg\" width=\"50%\" height=\"50%\">";
        break;
    case "House Baelish of Harrenhal":
        var el = document.getElementById("player_1");
        el.innerHTML="<img src=\"./Bilde/Icons/Man_GReen_Fame.svg\" width=\"50%\" height=\"50%\">";
        break;

    default:
        console.log("work, no info")

}

                                                            //plaserer på høyere av siden under dice2
switch (localStorage.getItem("player 2")) {
    case "House Algood":
    var el = document.getElementById("player_2_v");
    el.innerHTML="<img src=\"./Bilde/Icons/Algood_Gul.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Allyrion of Godsgrace":
    var el = document.getElementById("player_2_v");
    el.innerHTML="<img src=\"./Bilde/Icons/Hand_Dark_Red.svg\" width=\"50%\" height=\"50%\">";
    break;

case "House Amber":
    var el = document.getElementById("player_2_v");
    el.innerHTML="<img src=\"./Bilde/Banner_Whater.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Ambrose":
    var el = document.getElementById("player_2_v");
    el.innerHTML="<img src=\"./Bilde/Icons/Red_Mauer.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Appleton of Appleton":
    var el = document.getElementById("player_2_v");
    el.innerHTML="<img src=\"./Bilde/Icons/Wood_Kind_Gray.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Arryn of Gulltown":
    var el = document.getElementById("player_2_v");
    el.innerHTML="<img src=\"./Bilde/Icons/Blue_Hero.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Arryn of the Eyrie":
    var el = document.getElementById("player_2_v");
    el.innerHTML="<img src=\"./Bilde/Icons/Blue_Hero.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Ashford of Ashford":
    var el = document.getElementById("player_2_v");
    el.innerHTML = "<img src=\"./Bilde/Icons/Orang_son.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Ashwood":
    var el = document.getElementById("player_2_v");
    el.innerHTML = "<img src=\"./Bilde/Icons/Red_Skog.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Baelish of Harrenhal":
    var el = document.getElementById("player_2_v");
    el.innerHTML="<img src=\"./Bilde/Icons/Man_GReen_Fame.svg\" width=\"50%\" height=\"50%\">";
    break;


    default:
        console.log("work, no info")
}

                                                            //plaserer på starts linje 
switch (localStorage.getItem("player 2")) {
    case "House Algood":
    var el = document.getElementById("player2");
    el.innerHTML="<img src=\"./Bilde/Icons/Algood_Gul.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Allyrion of Godsgrace":
    var el = document.getElementById("player2");
    el.innerHTML="<img src=\"./Bilde/Icons/Hand_Dark_Red.svg\" width=\"50%\" height=\"50%\">";
    break;

case "House Amber":
    var el = document.getElementById("player2");
    el.innerHTML="<img src=\"./Bilde/Banner_Whater.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Ambrose":
    var el = document.getElementById("player2");
    el.innerHTML="<img src=\"./Bilde/Icons/Red_Mauer.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Appleton of Appleton":
    var el = document.getElementById("player2");
    el.innerHTML="<img src=\"./Bilde/Icons/Wood_Kind_Gray.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Arryn of Gulltown":
    var el = document.getElementById("player2");
    el.innerHTML="<img src=\"./Bilde/Icons/Blue_Hero.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Arryn of the Eyrie":
    var el = document.getElementById("player2");
    el.innerHTML="<img src=\"./Bilde/Icons/Blue_Hero.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Ashford of Ashford":
    var el = document.getElementById("player2");
    el.innerHTML = "<img src=\"./Bilde/Icons/Orang_son.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Ashwood":
    var el = document.getElementById("player2");
    el.innerHTML = "<img src=\"./Bilde/Icons/Red_Skog.svg\" width=\"50%\" height=\"50%\">";
    break;
case "House Baelish of Harrenhal":
    var el = document.getElementById("player2");
    el.innerHTML="<img src=\"./Bilde/Icons/Man_GReen_Fame.svg\" width=\"50%\" height=\"50%\">";
    break;


    default:
        console.log("work, no info")
}







//blue: #375DAA
//green: 57883D

/*
document.getElementsByClassName("button_Disk ").bgcolor="#375DAA";
*/


var play1 = {
    house: "#",
    tile: 0


}
var play2 = {
    house: "#",
    tile: 0


}


var start = 1;
var bigin = 1;

function rollDice() {                                          //dice player 1
    var die1 = document.getElementById("die1");
var i = 0;


function delayRoling1(){                                           //rompa er deslay på dicen. 
    document.getElementById("Button2").disabled = false;
    document.getElementById("Button2").style.background='#ffff';   
    setTimeout(() => {
        if(i == 15) {
            var d1 = Math.floor(Math.random() * 6) + 1;
            die1.innerHTML = d1;
            moving_blue(d1);
            document.getElementById("Button1").disabled = true;
            document.getElementById("Button1").style.background='#666666';   
                    
        }else{
            var d1 = Math.floor(Math.random() * 6) + 1;
            die1.innerHTML = d1;
            i++;
            delayRoling1();
        }
    }, 100);
}

delayRoling1();


  
   
}




function rollDice_2() {                                     //dice player 2
    var die2 = document.getElementById("die2");
    var i = 0
    
    function DelayRoling2(){                                               //rompa er deslay på dicen. 
        document.getElementById("Button1").disabled = false;
        document.getElementById("Button1").style.background='#ffff';   
        
        setTimeout(() => {
            if(i == 15) {
                var d2 = Math.floor(Math.random() * 6) + 1;
                die2.innerHTML = d2;
                moving_green(d2);
                document.getElementById("Button2").disabled = true;
                document.getElementById("Button2").style.background='#666666';    
            }else{
                var d2 = Math.floor(Math.random() * 6) + 1;
                die2.innerHTML = d2;
                i++;
                DelayRoling2();
            }
        }, 100);
    }
 
    DelayRoling2();
 
   

   
}



////Hjelp!!!!!!!11

function moving_blue(d1){

    var spillertur = 1;

    var player1 = document.getElementById("player1");
  

    if( spillertur == 1 ){
        spillertur = 2;
    } else {
        spillertur = 2;
    }
    var brikke = document.getElementById(start);

    
            //Card Standar farge 


    for(i = 0; i < d1; i++){
        setTimeout(function(){
            start = start + 1                       //forteller at nå dy trykker på d2 så skal den bevege seg 1 utifra det tallet 
            hasWon(start, "player 1");
            brikke = document.getElementById(start);        // dyttter den på brikketene
           
           
            brikke.appendChild(player1);                //flytter id
        }, 450 * i)
        
    }
    // brikke.style.backgroundColor = "#375DAA";               //independet color after players 
   myFeller(player1);
  
}






function moving_green(d2){

    var spillertur = 1;

     var player2 = document.getElementById("player2");

     if( spillertur == 1 ){
       spillertur = 2;
    } else {
        spillertur = 2;
    }
    var brikke2 = document.getElementById(bigin);        //henter den golbale variabelen 

    
   

    
    for(i = 0; i < d2; i++){
        setTimeout(function(){
            bigin = bigin + 1                       //forteller at nå dy trykker på d2 så skal den bevege seg 1 utifra det tallet 
            
            hasWon(bigin, "player 2");

            brikke2 = document.getElementById(bigin);        // dyttter den på brikketene
           
           
            brikke2.appendChild(player2);                //flytter id
        }, 450 * i)
  
    
        
    }
    myFeller(player2);

}









//help 
/////////////////////////////////////////////////////////////////help

function hasWon(currentTile, player) {
    if (currentTile >= 48) {


        
       // localstorage win = player
        if (player = "player 1"){
        
           
            localStorage.setItem("B" ,"player 1");
            window.location.href="Gol.html"
            
            console.log(hasWon);
           
        }else{
            localStorage.removeItem("Player 2"); 
        }
        if (player = "player 2") {
            localStorage.setItem("G" ,"player 2");
           
            window.location.href='Gol.html'
           
        }else{
            localStorage.removeItem("Player 1"); 
        }
       
    
     
     
       
    }

   
    return false;
}

//////////////////////////////////////////////////////////////////





             //independet color after players 







// var adi = document.getElementById("myadio");                //The audio volium controll 
// adi.volume = 0.1;
 




function myFeller(player){

    var feller = [ 19, 20, 30, 40, 23, 32, 25, 28, 44, 43, 47 ];
    for(var i = 0; i < feller.length; i++){
        if (feller[i] == start){ 
            alert("you are in prisen play1");
            Player_01_TRapp()
      
           
       
           
        }if (feller[i] ==  bigin ) {
            alert("you are in prisen play2");
            myTellerFeller()
            
           
                                            //forteller for loopen at når du kommer ut av fengsil skal du starte på id 13
        }
    }

}



// ned teler 
function myTellerFeller(){ 
    var timeleft = 30;
    var downloadTimer = setInterval(function(){
        document.getElementById("Button1").disabled = false;
        document.getElementById("Button1").style.background='#ffff'; 
       

    timeleft--;
    document.getElementById("countdown_Green").textContent = timeleft;
 
    
    if (brikke2 = isPlayer2InJail){
        var brikke2 = document.getElementById(90);
        brikke2.appendChild(player2);
        document.getElementById("Button2").disabled = true;
        document.getElementById("Button2").style.background='#666666';  
    }
    

    
    if(timeleft <= 0)                           //porblem  cant get the player icon to stay in the 90 id untill the timer rund out
  
        clearInterval(downloadTimer);
          
        return false;
       
    },1000);

    bigin = 13;
}









function Player_01_TRapp(){ 
    var timeleft = 30;
    var downloadTimer = setInterval(function(){
        
        document.getElementById("Button2").disabled = false;
        document.getElementById("Button2").style.background='#ffff'; 

    timeleft--;
    document.getElementById("Countdown_Blue").textContent = timeleft;
 
    
    if (brikke1 = isPlayer1InJail){
        var brikke1 = document.getElementById(90);
        brikke1.appendChild(player1);
        document.getElementById("Button1").disabled = true;
        document.getElementById("Button1").style.background='#666666';  
    }
    

    
    if(timeleft <= 0)                           //porblem  cant get the player icon to stay in the 90 id untill the timer rund out
            
            
        clearInterval(downloadTimer);
      
        return false;
       
    },1000);
    
    start = 13;
}